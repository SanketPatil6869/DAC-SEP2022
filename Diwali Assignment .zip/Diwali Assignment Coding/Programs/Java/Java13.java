public class Java13 {
    
   
    public static void greet()
    {
        System.out.println(
            "Hey Geeks! Welcome to NoWhere.");
        
       
        return;
    }
    public static void main(String args[])
    {
        
        greet();
    }
}